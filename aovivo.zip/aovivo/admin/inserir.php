<div class="card">
  <div class="card-header">
    <h1 class="font-weight-bold text-xl-left">Inserir Lives Futuras</h1>
  </div>
  <div class="card-body font-weight-bold text-xl-left">
    <blockquote class="blockquote mb-0">

<form action="?pg=inserirdb" method="post">
<table> 
    <tr> 
        <td>Nome do artista: </td>
        <td><input name="nome" type="text"/></td>
    </tr>
    <tr> 
        <td>Data: </td>
        <td><input name="data" type="text"/></td>
    </tr>
     <tr> 
        <td>hora: </td>
        <td><input name="hora" type="text"/></td>
    </tr>
    <tr> 
        <td>local: </td>
        <td><input name="local" type="text"/></td>
    </tr>
    <tr>
        <td></td>
        <td><button name="Enviar">Cadastrar</button></td>
    </tr>
</table>
</form>
</blockquote>
</div>
</div>