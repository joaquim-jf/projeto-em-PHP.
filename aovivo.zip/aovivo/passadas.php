<div class="card">
  <div class="card-header">
    <h1 class="font-weight-bold text-xl-left">Lives nacionais que já passaram
 </h1>
  </div>
  <div class="card-body">
    <blockquote class="blockquote mb-0">
      <ul class="font-weight-bold text-xl-left"> 
      <li>10/04 – Live do Djonga</li>
      <li>15/04 – Live do Grupo Revelação</li>
      <li>30/04 – Live do Filipe Ret</li>
      <li>08/05 – Live do Fábio Jr.</li>
      <li>08/05 – Live Mastruz com Leite</li>
      <li>09/05 – Live Fernando e Sorocaba</li>
      <li>09/05 – Live do Lucas Lucco</li>
      <li>10/05 – Live do Zeca Pagodinho</li>
      <li>11/05 – Live da Aiyra</li>
      <li>12/05 – Live da Simony</li>
      <li>12/05 – Live Sampa Crew</li>
    </ul>
</table>
    </blockquote>
  </div>
</div>