   <nav class="navbar navbar-expand-md navbar-dark bg-dark">
  <a class="navbar-brand" href="?pg=principal">LivesOn</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"> 
    <span class="navbar-toggler-icon ">
    </span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav">
      <li class="nav-item ">
        <a class="nav-link" href="?pg=informacao">Informaçoes <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="?pg=contato">Contato</a>
      </li>
       </ul>
  </div>
</nav>