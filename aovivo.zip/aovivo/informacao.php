<div class="card">
  <div class="card-header">
    <h1 class="font-weight-bold text-xl-left">Shows para assistir em casa</h1>
  </div>
  <div class="card-body">
    <blockquote class="blockquote mb-0">
      <p class="font-weight-normal text-xl-left">Devido à epidemia do coronavírus, vários shows foram cancelados no<br> Brasil e em todo o mundo. Mas os artistas tem dado um jeitinho de manter<br> os fãs animados: fazendo lives!</p>

        <p class="font-weight-normal text-xl-left"><br>Os shows são transmitidos ao vivo através das redes sociais e garantem<br> a alegria de quem sente falta daquele happy hour do fim de semana.
        </p>

        <p class="font-weight-normal text-xl-left"> Nos da LivesOn, criamos o site para ajudar o pessoal continuar em casa e não perder nehuma Live!
        </p>
    </blockquote>
  </div>
</div>


