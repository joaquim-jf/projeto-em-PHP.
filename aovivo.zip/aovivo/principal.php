  <?php include_once('topo.php') ?>


  <div class="album py-5 bg-dark">
    <div class="container ">

      <div class="row">
        <div class="col-md-4">
          <div class="card mb-4" >
            <img src="https://www.vagalume.com.br/dynimage/news34973-big.jpg" width="100%" height="100%"><title>Katy Perry </title><text x="50%" y="50%" fill="#eceeef" dy=".3em"></text>
            <div class="card-body">
              <p class="card-text">Katy Perry </p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">Assistir</button>
                </div>
                <small class="text-muted "> começou a agora </small>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card mb-4 ">
            <img src="https://www.movimentocountry.com/wp-content/uploads/2019/12/gusttavo-lima-boicote.jpg"  width="100%" height="200" ><title>Gustavo Lima</title><text x="50%" y="50%" fill="#eceeef" dy=".3em"></text>
            <div class="card-body">
              <p class="card-text">Gustavo Lima</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">Assistir</button>
                </div>
                <small class="text-muted">começou a 1 hora</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card mb-4 ">
            <img src="https://ogimg.infoglobo.com.br/in/24367056-73a-f6d/FT1086A/652/87575815_SCO-rapper-Djonga.jpg"  width="100%" height="200" ><title>Djonga</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em"></text>
            <div class="card-body">
              <p class="card-text">Djonga</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">Assistir</button>
                </div>
                <small class="text-muted">começa em 1 hora</small>
              </div>
            </div>
          </div>
        </div>
    </div>
</div>
</div>

           