<footer class="text-muted">
  <div class="container">
    <p class="float-right">
      <a href="#">^Topo pagina^</a>
    </p>
    <p>&copy;LivesOn!</p>
    <p>Redes sociais <a href="https://www.instagram.com/?hl=pt-br">Instagram</a> e <a href="https://twitter.com/login?lang=pt">Twitter</a>.</p>
  </div>
</footer>