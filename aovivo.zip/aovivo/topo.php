<?php include_once('menu.php') ?>


  <section class="jumbotron text-center ">
    <div class="container ">
      <h1><img src="img/lives.png"></h1>
      <p class="lead text-muted"></p>
      <p>
        <a href="?pg=futuras" class="btn btn-primary my-2 ">Lives</a>
        <a href="?pg=passadas" class="btn btn-secondary my-2">Lives passadas</a>
      </p>
    </div>
  </section>
